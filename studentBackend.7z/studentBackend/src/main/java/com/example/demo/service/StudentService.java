package com.example.demo.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.example.demo.model.Student;

public interface StudentService {

//	Employee  related service
	Student saveStudent(Student student);

	Page<Student> getAllStudent(int page,int size);

	Student getStudentById(Long id);

	Student UpdateStudent(Long id, Student student);

	void deleteStudent(Long id);
	
	void  deleteSubject(Long id);

}
