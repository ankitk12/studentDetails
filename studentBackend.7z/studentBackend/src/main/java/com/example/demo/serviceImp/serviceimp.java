package com.example.demo.serviceImp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.Repository.studentRepo;
import com.example.demo.Repository.subjectRepo;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Student;
import com.example.demo.service.StudentService;

@Service
public class serviceimp implements StudentService {

	@Autowired
	private studentRepo studentrepo;
	@Autowired
	private subjectRepo subjectrepo;

	@Override
	public Student saveStudent(Student student) {
		// TODO Auto-generated method stub
		return studentrepo.save(student);
	}

	@Override
	public Page<Student> getAllStudent(int page,int size) {
		// TODO Auto-generated method stub
		return studentrepo.findAll(PageRequest.of(page, size));
	}

	@Override
	public Student getStudentById(Long id) {
		// TODO Auto-generated method stub
		return studentrepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Student", "id", id));
	}

	@Override
	public Student UpdateStudent(Long id, Student student) {
		// TODO Auto-generated method stub
		Student existingStudent = studentrepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Student", "id", id));
		existingStudent.setName(student.getName());
		existingStudent.setRollNo(student.getRollNo());
		existingStudent.setCountry(student.getCountry());
		existingStudent.setBirthdate(student.getBirthdate());
		existingStudent.setGender(student.getGender());
		existingStudent.setHobbies(student.getHobbies());
		existingStudent.setPresentaddress(student.getPresentaddress());
		existingStudent.setPermamentaddress(student.getPermamentaddress());
		existingStudent.setSubject(student.getSubject());
		studentrepo.save(existingStudent);
		return existingStudent;
	}

	@Override
	public void deleteStudent(Long id) {
		// TODO Auto-generated method stub
		studentrepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Student", "id", id));
		studentrepo.deleteById(id);
	}

	@Override
	public void deleteSubject(Long id) {
		// TODO Auto-generated method stub
		subjectrepo.deleteById(id);
	}

}
