package com.example.demo.model;

import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "Student")
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Column(name = "Name")
	private String name;

	@Column(name = "Roll_No")
	private int rollNo;

	@Column(name = "country")
	private String country;

	@Column(name = "Birthdate")
	private Date birthdate;

	@Column(name = "Gender")
	private String gender;

	@Column(name = "Contact_No")
	private String contactno;

	@Column(name = "Hobbies")
	private String hobbies;

	@Column(name = "presentAddress")
	private String presentaddress;

	@Column(name = "permamentAddress")
	private String permamentaddress;

	@OneToMany(targetEntity = Subject.class, cascade = CascadeType.ALL)
	@JoinColumn(name = "studentId")
	private List<Subject> subject;
}
